from django.urls import path
from . import views
app_label = 'main'
urlpatterns = [
    path('',views.homepage, name = 'homepage')
]
